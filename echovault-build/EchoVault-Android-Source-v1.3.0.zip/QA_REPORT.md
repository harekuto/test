# EchoVault v1.3.0 — recording-preservation engineering QA

Date: 2026-10-20

## Baseline
- Received `EchoVault-Android-Source-v1.2.0.zip` and `EchoVault-v1.2.0-debug.apk`.
- Source is native Android Java, package/applicationId `com.harekuto.echovault`, minimum SDK 26, target/compile SDK 35, Android Gradle Plugin 8.7.3, JDK target 17. Project docs request Gradle 8.9; wrapper is not in source.
- v1.2.0 retention default was 48h. `RetentionManager.prune()` previously deleted eligible files from `EchoVault/Temporary` and `finishSegment()` deleted `.partial` on errors.

## Changes to production code
- `RetentionPolicy` defaults to retention OFF; its `mayDelete` predicate always returns false.
- `RetentionManager.prune()` is non-destructive even with historic 48h preference; scheduled v1.2 cleanup JobScheduler task is canceled on app/service startup.
- `RetentionJobService` is a harmless compatibility target for already-scheduled jobs.
- Recording files use unique reserved `.m4a.partial` names in the permanent EchoVault root. `MediaRecorder.stop()` plus `MediaMetadataRetriever` verifies a nonzero duration before a non-overwriting filesystem move publishes `.m4a`.
- On failure, source `.partial` bytes stay on storage and become discoverable in the archive rather than being erased.
- Archive enumerates both app-internal and app-specific external roots and both `EchoVault` and legacy `EchoVault/Temporary` folders without moving older data. Incomplete files are labeled and exportable.
- Archive sorting is by recency, removing previous implicit promotion of every root-level legacy item above recent recordings.
- Existing `.keep` favorites and legacy preference keys remain usable; manual delete requires confirmation, and active exports block deletion.
- Version bumped to 1.3.0 / versionCode 4 without changing applicationId.

## Actual checks executed
- PASS: local `javac -Xlint:all` for pure-Java archive, codec settings and retention policy sources.
- PASS: 14 Java regression tests (4 settings, 7 retention, 3 archive) with JUnit-compatible local shim and `-Xverify:all` JVM run.
- PASS: all 11 Java main/test files parsed using the JDK JavaCompiler parser, independent of unresolved Android SDK symbols.
- PASS: Android manifest + 5 resource XML files parsed as well-formed XML.
- PASS: checked that app build metadata is versionCode 4 / versionName 1.3.0.

## Not tested / blockers
- NOT RUN: `:app:compileDebugJavaWithJavac`, `:app:testDebugUnitTest`, `:app:assembleDebug` because Android SDK and Gradle are not installed in this execution container; the source has no wrapper.
- NOT CREATED: a genuine v1.3.0 APK. The uploaded v1.2.0 APK remains untouched.
- NOT RUN: device installation, microphone recording, fragment boundary, locked screen, low storage, playback, backup/external export, UI interaction, or Android background execution.
- NOT VERIFIED: signing key equality for safe upgrade from any previously installed v1.2.0 debug APK; the original signing key is not provided.
- NOT VERIFIED: historical recordings on the user's physical device; only project code and synthetic test files are accessible here.

## Known limits / essential precautions
- Partial files stopped mid-container-writing may lack necessary MP4 structure and cannot be guaranteed playable. Their bytes are preserved for attempted recovery/export.
- Android app-specific data may disappear after uninstall, Clear storage, or device failure regardless of auto-retention policy. Export important audio to user-selected storage.
- Updates signed with a different certificate cannot normally replace the existing Android install while retaining its app-private data. Never uninstall a recording-bearing v1.2.0 installation solely to install a new debug APK.
- Persistent device recordings are not copied into the source ZIP or APK.
