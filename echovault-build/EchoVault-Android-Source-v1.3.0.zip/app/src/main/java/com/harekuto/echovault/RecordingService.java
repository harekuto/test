package com.harekuto.echovault;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.io.File;
import java.io.IOException;

/** Visible, user-initiated microphone foreground service. No wake lock or network access. */
public final class RecordingService extends Service {
    public static final String ACTION_START = "com.harekuto.echovault.START";
    public static final String ACTION_STOP = "com.harekuto.echovault.STOP";
    public static final String ACTION_PAUSE = "com.harekuto.echovault.PAUSE";
    public static final String ACTION_SAVE_CURRENT = "com.harekuto.echovault.SAVE_CURRENT";
    public static final String ACTION_RESUME = "com.harekuto.echovault.RESUME";
    public static final String PREFS = "echo_settings";
    public static final String KEY_ERROR = "last_error";
    public static final String KEY_QUALITY = "quality";
    public static final String KEY_SEGMENT = "segment";

    private static final String CHANNEL_ID = "recording_channel";
    private static final int NOTIFICATION_ID = 100;
    private static final long LOW_SPACE_BYTES = 200L * 1024L * 1024L;

    private static volatile boolean active;
    private static volatile boolean paused;
    private static volatile long startedElapsed;
    private static volatile String segmentLabel = "";
    private static volatile String currentPartialPath = "";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;
    private File partialFile;
    private File finishedFile;
    private boolean foregroundStarted;
    private int quality;
    private long segmentMillis;
    private long segmentStartedElapsed;

    private final Runnable rotate = new Runnable() {
        @Override public void run() {
            if (!active) return;
            if (paused) {
                handler.postDelayed(this, 30_000L);
                return;
            }
            try {
                if (!finishSegment()) throw new IOException("сбой завершения сегмента; .partial сохранён в архиве");
                beginSegment();

            } catch (Exception e) {
                terminateWithError("Запись остановлена: " + meaningfulError(e));
            }
        }
    };

    public static boolean isActive() { return active; }
    public static boolean isPaused() { return paused; }
    public static long startedElapsed() { return startedElapsed; }
    public static String currentSegment() { return segmentLabel; }
    public static String currentPartialPath() { return currentPartialPath; }

    @Override public void onCreate() {
        super.onCreate();
        active = false;
        paused = false;
        createNotificationChannel();
        RetentionManager.configureJob(this); // Cancel any v1.2.0 scheduled deletion job.
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action)) {
            pauseRecording();
            return START_NOT_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            resumeRecording();
            return START_NOT_STICKY;
        }
        if (ACTION_SAVE_CURRENT.equals(action)) {
            saveCurrentSegment();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action) && !active) {
            startRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            terminateWithError("Нет разрешения на использование микрофона");
            return;
        }
        try {
            quality = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_QUALITY, 1);
            int segmentIndex = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_SEGMENT, 1);
            segmentMillis = RecorderSettings.segmentMinutes(segmentIndex) * 60_000L;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_ERROR).apply();
            startVisibleForeground();
            foregroundStarted = true;
            startedElapsed = SystemClock.elapsedRealtime();
            active = true;
            paused = false;
            beginSegment();

        } catch (Exception e) {
            terminateWithError("Не удалось начать запись: " + meaningfulError(e));
        }
    }

    private void beginSegment() throws IOException {
        File directory = RecordingFiles.directory(this);
        if (directory.getUsableSpace() < LOW_SPACE_BYTES) {
            throw new IOException("свободно менее 200 МБ памяти");
        }
        partialFile = RecordingArchive.reserveNewPartial(directory, RecordingFiles.timestamp());
        finishedFile = RecordingArchive.finishedName(partialFile);
        currentPartialPath = partialFile.getAbsolutePath();
        // MediaRecorder uses platform hardware audio encoders when available.
        MediaRecorder current = new MediaRecorder();
        recorder = current;
        current.setAudioSource(MediaRecorder.AudioSource.MIC);
        current.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        current.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        current.setAudioChannels(1);
        current.setAudioSamplingRate(RecorderSettings.sampleRate(quality));
        current.setAudioEncodingBitRate(RecorderSettings.bitRate(quality));
        current.setOutputFile(partialFile.getAbsolutePath());
        current.setOnErrorListener((mr, what, extra) ->
                terminateWithError("Ошибка аудиозаписи: код " + what + "/" + extra));
        current.prepare();
        current.start();
        segmentStartedElapsed = SystemClock.elapsedRealtime();
        segmentLabel = finishedFile.getName();
        handler.removeCallbacks(rotate);
        handler.postDelayed(rotate, segmentMillis);
        if (foregroundStarted) notifyStatus();
    }

    /** Stop, validate playback metadata, then atomically publish a unique completed recording.
     * On ANY failure keep the .partial file for manual recovery/export in the archive. */
    private boolean finishSegment() {
        handler.removeCallbacks(rotate);
        MediaRecorder old = recorder;
        recorder = null;
        if (old == null) return false;
        boolean stopped = false;
        try {
            old.stop();
            stopped = true;
        } catch (RuntimeException ignored) {
            // A terminated encoder may have left salvageable bytes; never erase them.
        } finally {
            try { old.reset(); } catch (RuntimeException ignored) { }
            try { old.release(); } catch (RuntimeException ignored) { }
        }
        boolean completed = stopped && partialFile != null && finishedFile != null &&
                validAudio(partialFile) &&
                RecordingArchive.finalizeWithoutOverwrite(partialFile, finishedFile);
        // If finalization fails, .partial remains visible as an unfinished file in history.
        partialFile = null;
        finishedFile = null;
        currentPartialPath = "";
        segmentLabel = "";
        return completed;
    }

    private static boolean validAudio(File file) {
        if (!file.isFile() || file.length() <= 0) return false;
        MediaMetadataRetriever metadata = new MediaMetadataRetriever();
        try {
            metadata.setDataSource(file.getAbsolutePath());
            String duration = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return duration != null && Long.parseLong(duration) > 0;
        } catch (Exception ignored) {
            return false;
        } finally {
            try { metadata.release(); } catch (RuntimeException ignored) { }
        }
    }

    /** Close and permanently save the current segment without stopping the recording session. */
    private void saveCurrentSegment() {
        if (!active || recorder == null || paused) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_ERROR, "Для сохранения текущего фрагмента возобновите запись").apply();
            return;
        }
        if (SystemClock.elapsedRealtime() - segmentStartedElapsed < 2000L) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_ERROR, "Запись слишком короткая: сохраните фрагмент через несколько секунд").apply();
            return;
        }
        File target = finishedFile;
        try {
            if (!finishSegment()) throw new IOException("сбой сохранения; .partial сохранён в архиве");
            boolean kept = RetentionManager.setSaved(this, target, true);
            beginSegment(); // Continue automatically, no Stop/Start required.
            if (!kept) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(KEY_ERROR, "Фрагмент записан, но не удалось закрепить его. Сохраните в архиве").apply();
            } else {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_ERROR).apply();
            }
            notifyStatus();
        } catch (Exception e) {
            terminateWithError("Не удалось сохранить текущий фрагмент: " + meaningfulError(e));
        }
    }

    private void pauseRecording() {
        if (!active || paused || recorder == null) return;
        try {
            recorder.pause();
            paused = true;
            handler.removeCallbacks(rotate);
            notifyStatus();
        } catch (RuntimeException e) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_ERROR, "Не удалось поставить на паузу: " + meaningfulError(e)).apply();
        }
    }
    private void resumeRecording() {
        if (!active || !paused || recorder == null) return;
        try {
            recorder.resume();
            paused = false;
            handler.removeCallbacks(rotate);
            handler.postDelayed(rotate, segmentMillis);
            notifyStatus();
        } catch (RuntimeException e) {
            terminateWithError("Не удалось возобновить запись: " + meaningfulError(e));
        }
    }
    private void stopRecording() {
        active = false;
        paused = false;
        handler.removeCallbacks(rotate);
        boolean hadRecorder = recorder != null;
        boolean saved = finishSegment();
        if (hadRecorder && !saved && settingsErrorAbsent()) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_ERROR, "Не удалось завершить сегмент; исходный .partial сохранён в архиве для восстановления").apply();
        }
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
        }

        stopSelf();
    }
    private boolean settingsErrorAbsent() {
        return !getSharedPreferences(PREFS, MODE_PRIVATE).contains(KEY_ERROR);
    }
    private void terminateWithError(String error) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ERROR, error).apply();
        stopRecording();
    }
    private static String meaningfulError(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Запись микрофона", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Постоянное уведомление о фоновой записи аудио");
        channel.setSound(null, null);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String action = paused ? ACTION_RESUME : ACTION_PAUSE;
        PendingIntent toggle = PendingIntent.getService(this, 2,
                new Intent(this, RecordingService.class).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent save = PendingIntent.getService(this, 4,
                new Intent(this, RecordingService.class).setAction(ACTION_SAVE_CURRENT),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 3,
                new Intent(this, RecordingService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(paused ? "EchoVault · Пауза" : "EchoVault · Запись идёт")
                .setContentText(paused ? "Микрофон на паузе" : "Постоянный архив · запись сохраняется локально")
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(R.drawable.ic_notification, paused ? "Продолжить" : "Пауза", toggle)
                .addAction(R.drawable.ic_notification, "Сохранить", save)
                .addAction(R.drawable.ic_notification, "Остановить", stop)
                .build();
    }
    private void startVisibleForeground() {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, notification());
        }
    }
    private void notifyStatus() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID, notification());
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(rotate);
        active = false;
        paused = false;
        finishSegment();
        super.onDestroy();
    }
}
