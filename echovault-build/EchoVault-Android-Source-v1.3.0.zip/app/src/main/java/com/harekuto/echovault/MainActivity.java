package com.harekuto.echovault;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MainActivity extends Activity {
    private static final int MIC_REQUEST = 1001;
    private static final int NOTIFICATION_REQUEST = 1002;
    private static final int SAVE_REQUEST = 1003;
    private static final int BG = Color.rgb(8, 17, 27);
    private static final int PANEL = Color.rgb(17, 31, 43);
    private static final int PANEL_LIGHT = Color.rgb(24, 43, 54);
    private static final int ACCENT = Color.rgb(112, 232, 188);
    private static final int TEXT = Color.rgb(236, 249, 246);
    private static final int MUTED = Color.rgb(151, 177, 184);
    private static final int DANGER = Color.rgb(255, 150, 147);

    private LinearLayout root;
    private LinearLayout page;
    private LinearLayout nav;
    private TextView status;
    private TextView timer;
    private TextView activeFile;
    private TextView mainButton;
    private TextView pauseButton;
    private TextView saveCurrentButton;
    private TextView errorLabel;
    private LinearLayout recordingsList;
    private TextView totalLabel;
    private int tab;
    private int visibleLimit = 20;
    private String filter = "";
    private boolean visible;
    private File exportSource;
    private MediaPlayer player;
    private String playingPath;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!visible) return;
            if (tab == 0) updateRecorderUI();
            uiHandler.postDelayed(this, 1000L);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        root = vertical();
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            root.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(root);
        if (state != null) {
            String path = state.getString("pending_export");
            if (path != null) {
                exportSource = new File(path);
                RetentionManager.reserve(exportSource);
            }
            tab = state.getInt("selected_tab", 0);
        }
        RetentionManager.configureJob(this);
        showTab(tab);
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putInt("selected_tab", tab);
        if (exportSource != null) state.putString("pending_export", exportSource.getAbsolutePath());
    }
    @Override protected void onResume() {
        super.onResume();
        visible = true;
        uiHandler.removeCallbacks(tick);
        uiHandler.post(tick);
        if (tab == 1) {
            showRecordings();
        }
    }
    @Override protected void onPause() {
        visible = false;
        uiHandler.removeCallbacks(tick);
        if (player != null) {
            try { if (player.isPlaying()) player.pause(); } catch (IllegalStateException ignored) { }
        }
        super.onPause();
    }
    @Override protected void onDestroy() {
        releasePlayer();
        if (exportSource != null) RetentionManager.release(exportSource);
        super.onDestroy();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }
    private LinearLayout horizontal() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(sp);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private GradientDrawable background(int color, int radius, int borderColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (borderColor != Color.TRANSPARENT) d.setStroke(dp(1), borderColor);
        return d;
    }
    private void panelBackground(View v, int color, int radius) {
        v.setBackground(background(color, radius, Color.rgb(39, 62, 69)));
    }
    private TextView action(String s, int color, int foreground, int radius, Runnable callback) {
        TextView t = label(s, 14, foreground, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(44));
        GradientDrawable shape = background(color, radius, color == ACCENT ? Color.TRANSPARENT : Color.rgb(52, 73, 81));
        t.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), shape, null));
        t.setClickable(true);
        t.setFocusable(true);
        t.setOnClickListener(v -> callback.run());
        return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }
    private void addGap(LinearLayout parent, int height) {
        View gap = new View(this);
        parent.addView(gap, lp(-1, height));
    }
    private void showTab(int selected) {
        tab = selected;
        status = timer = activeFile = mainButton = pauseButton = saveCurrentButton = errorLabel = null;
        root.removeAllViews();
        LinearLayout header = horizontal();
        header.setPadding(dp(23), dp(22), dp(23), dp(12));
        TextView icon = label("≋", 30, ACCENT, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(background(PANEL_LIGHT, 14, Color.TRANSPARENT));
        header.addView(icon, lp(46, 46));
        LinearLayout titles = vertical();
        titles.setPadding(dp(12), 0, 0, 0);
        TextView brand = label("ECHOVAULT", 21, TEXT, true);
        brand.setLetterSpacing(.09f);
        titles.addView(brand);
        titles.addView(label("PRIVATE AUDIO JOURNAL", 10, MUTED, true));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView local = label("● LOCAL", 10, ACCENT, true);
        local.setGravity(Gravity.CENTER);
        local.setPadding(dp(11), dp(7), dp(11), dp(7));
        local.setBackground(background(Color.rgb(23, 55, 50), 25, Color.TRANSPARENT));
        header.addView(local);
        root.addView(header);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        page = vertical();
        page.setPadding(dp(22), dp(12), dp(22), dp(28));
        scroll.addView(page);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (selected == 0) showRecorder();
        else if (selected == 1) showRecordings();
        else showSettings();
        showNavigation();
    }
    private void showNavigation() {
        nav = horizontal();
        nav.setPadding(dp(14), dp(12), dp(14), dp(12));
        nav.setBackgroundColor(Color.rgb(12, 26, 37));
        String[] labels = {"◉  Запись", "▤  Архив", "⚙  Настройки"};
        for (int i = 0; i < 3; i++) {
            final int index = i;
            TextView b = label(labels[i], 13, tab == i ? ACCENT : MUTED, tab == i);
            b.setGravity(Gravity.CENTER);
            b.setMinHeight(dp(46));
            if (tab == i) b.setBackground(background(PANEL_LIGHT, 13, Color.TRANSPARENT));
            b.setOnClickListener(v -> showTab(index));
            b.setClickable(true);
            b.setFocusable(true);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(46), 1);
            if (i > 0) p.leftMargin = dp(7);
            nav.addView(b, p);
        }
        root.addView(nav);
    }
    private void section(String kicker, String title, String subtitle) {
        TextView k = label(kicker, 12, ACCENT, true);
        k.setLetterSpacing(.11f);
        page.addView(k);
        addGap(page, 8);
        page.addView(label(title, 31, TEXT, true));
        addGap(page, 9);
        page.addView(label(subtitle, 14, MUTED, false));
        addGap(page, 24);
    }
    private void showRecorder() {
        section("CAPTURE / 01", "Записывайте жизнь.", "Потоковая запись без сети и лишней нагрузки.");
        LinearLayout hero = vertical();
        hero.setPadding(dp(19), dp(22), dp(19), dp(23));
        GradientDrawable heroGradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(21, 52, 59), Color.rgb(16, 32, 47), Color.rgb(15, 29, 39)});
        heroGradient.setCornerRadius(dp(25));
        heroGradient.setStroke(dp(1), Color.rgb(41, 77, 76));
        hero.setBackground(heroGradient);
        LinearLayout row = horizontal();
        status = label("ГОТОВ К ЗАПИСИ", 12, ACCENT, true);
        status.setLetterSpacing(.08f);
        row.addView(status, new LinearLayout.LayoutParams(0, dp(28), 1));
        TextView pill = label("AAC · M4A", 11, MUTED, true);
        pill.setPadding(dp(10), dp(6), dp(10), dp(6));
        pill.setBackground(background(Color.rgb(30, 53, 64), 15, Color.TRANSPARENT));
        row.addView(pill);
        hero.addView(row);
        addGap(hero, 14);
        hero.addView(new WaveformView(this), lp(-1, 105));
        addGap(hero, 13);
        timer = label("00:00:00", 36, TEXT, true);
        timer.setGravity(Gravity.CENTER);
        timer.setLetterSpacing(.03f);
        hero.addView(timer);
        addGap(hero, 7);
        activeFile = label("Микрофон выключен", 12, MUTED, false);
        activeFile.setGravity(Gravity.CENTER);
        activeFile.setSingleLine(true);
        activeFile.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        hero.addView(activeFile);
        addGap(hero, 22);
        mainButton = action("●   Начать запись", ACCENT, BG, 16, this::toggleRecording);
        mainButton.setMinHeight(dp(59));
        hero.addView(mainButton, lp(-1, 60));
        addGap(hero, 9);
        pauseButton = action("Ⅱ   Пауза", PANEL_LIGHT, TEXT, 14, this::pauseResume);
        hero.addView(pauseButton, lp(-1, 46));
        addGap(hero, 9);
        saveCurrentButton = action("◆   Сохранить текущий фрагмент", PANEL_LIGHT, ACCENT, 14,
                () -> { sendService(RecordingService.ACTION_SAVE_CURRENT);
                        toast("Сохранение текущего фрагмента запрошено"); });
        hero.addView(saveCurrentButton, lp(-1, 46));
        page.addView(hero);
        addGap(page, 16);
        errorLabel = label("", 13, DANGER, false);
        errorLabel.setPadding(dp(13), dp(11), dp(13), dp(11));
        errorLabel.setBackground(background(Color.rgb(58, 32, 39), 10, Color.TRANSPARENT));
        page.addView(errorLabel);
        addGap(page, 16);
        LinearLayout grid = horizontal();
        SharedPreferences prefs = settings();
        int q = prefs.getInt(RecordingService.KEY_QUALITY, 1);
        int chunks = prefs.getInt(RecordingService.KEY_SEGMENT, 1);
        grid.addView(metric("КАЧЕСТВО", new String[]{"ЭКО", "БАЛАНС", "HI-FI"}[RecorderSettings.sanitizeQuality(q)], "Моно · AAC"),
                new LinearLayout.LayoutParams(0, dp(111), 1));
        LinearLayout.LayoutParams mid = new LinearLayout.LayoutParams(0, dp(111), 1);
        mid.leftMargin = dp(10);
        grid.addView(metric("СЕГМЕНТ", RecorderSettings.segmentMinutes(chunks) + " мин", "Файлы M4A"), mid);
        page.addView(grid);
        addGap(page, 19);
        TextView info = label("После ручного запуска запись продолжается через день и ночь, пока служба активна. Каждый завершённый фрагмент сохраняется в постоянный локальный архив без автоматического удаления. Кнопка ◆ досрочно завершает текущий фрагмент и продолжает запись. Android показывает уведомление и индикатор микрофона.", 13, MUTED, false);
        info.setLineSpacing(dp(4), 1f);
        page.addView(info);
        updateRecorderUI();
    }
    private LinearLayout metric(String key, String value, String hint) {
        LinearLayout box = vertical();
        box.setPadding(dp(16), dp(15), dp(10), dp(12));
        panelBackground(box, PANEL, 18);
        box.addView(label(key, 10, MUTED, true));
        addGap(box, 10);
        box.addView(label(value, 19, TEXT, true));
        addGap(box, 7);
        box.addView(label(hint, 11, MUTED, false));
        return box;
    }
    private void updateRecorderUI() {
        if (status == null || timer == null || mainButton == null || pauseButton == null) return;
        boolean recording = RecordingService.isActive();
        boolean paused = RecordingService.isPaused();
        status.setText(recording ? (paused ? "Ⅱ  ЗАПИСЬ НА ПАУЗЕ" : "●  ИДЁТ ЗАПИСЬ") : "○  ГОТОВ К ЗАПИСИ");
        timer.setText(recording ? elapsed(SystemClock.elapsedRealtime() - RecordingService.startedElapsed()) : "00:00:00");
        activeFile.setText(recording ? (paused ? "Пауза · сохранение после остановки" : RecordingService.currentSegment()) : "Микрофон выключен");
        mainButton.setText(recording ? "■   Остановить запись" : "●   Начать запись");
        mainButton.setTextColor(recording ? TEXT : BG);
        mainButton.setBackground(background(recording ? Color.rgb(122, 55, 64) : ACCENT, 16, Color.TRANSPARENT));
        pauseButton.setVisibility(recording ? View.VISIBLE : View.GONE);
        if (saveCurrentButton != null) {
            saveCurrentButton.setVisibility(recording ? View.VISIBLE : View.GONE);
            saveCurrentButton.setEnabled(!paused);
            saveCurrentButton.setAlpha(paused ? 0.5f : 1f);
        }
        pauseButton.setText(paused ? "▶   Продолжить запись" : "Ⅱ   Пауза");
        String error = settings().getString(RecordingService.KEY_ERROR, null);
        if (errorLabel != null) {
            errorLabel.setVisibility(error == null ? View.GONE : View.VISIBLE);
            if (error != null) errorLabel.setText(error);
        }
    }
    private static String elapsed(long millis) {
        long secs = Math.max(0, millis / 1000L);
        return String.format(Locale.ROOT, "%02d:%02d:%02d", secs / 3600, (secs / 60) % 60, secs % 60);
    }
    private SharedPreferences settings() { return getSharedPreferences(RecordingService.PREFS, MODE_PRIVATE); }
    private void toggleRecording() {
        if (RecordingService.isActive()) sendService(RecordingService.ACTION_STOP);
        else startWithPermissions();
        uiHandler.postDelayed(this::updateRecorderUI, 300);
    }
    private void pauseResume() {
        sendService(RecordingService.isPaused() ? RecordingService.ACTION_RESUME : RecordingService.ACTION_PAUSE);
        uiHandler.postDelayed(this::updateRecorderUI, 250);
    }
    private void startWithPermissions() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !settings().getBoolean("notification_asked", false)) {
            settings().edit().putBoolean("notification_asked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
            return;
        }
        sendService(RecordingService.ACTION_START);
    }
    private void sendService(String action) {
        try {
            Intent intent = new Intent(this, RecordingService.class).setAction(action);
            if (RecordingService.ACTION_START.equals(action)) startForegroundService(intent);
            else startService(intent);
        } catch (RuntimeException e) {
            Toast.makeText(this, "Невозможно запустить запись: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startWithPermissions();
            else Toast.makeText(this, "Без разрешения микрофона запись невозможна", Toast.LENGTH_LONG).show();
        } else if (requestCode == NOTIFICATION_REQUEST) {
            // Notification permission is optional for a microphone foreground service.
            sendService(RecordingService.ACTION_START);
        }
    }

    private void showRecordings() {
        page.removeAllViews();
        section("ARCHIVE / 02", "Мои записи.", "Только на вашем устройстве. Выберите файл для прослушивания или экспорта.");
        LinearLayout summary = vertical();
        summary.setPadding(dp(17), dp(18), dp(17), dp(18));
        panelBackground(summary, PANEL, 20);
        summary.addView(label("ЛОКАЛЬНОЕ ХРАНИЛИЩЕ", 11, ACCENT, true));
        addGap(summary, 8);
        totalLabel = label("—", 25, TEXT, true);
        summary.addView(totalLabel);
        addGap(summary, 6);
        summary.addView(label("Автоудаление полностью отключено. История всех версий сохраняется локально, пока вы сами не удалите файл или данные приложения.", 12, MUTED, false));
        page.addView(summary);
        addGap(page, 17);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(TEXT);
        search.setHintTextColor(MUTED);
        search.setHint("Поиск по дате или имени…");
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(background(PANEL_LIGHT, 13, Color.TRANSPARENT));
        search.setText(filter);
        page.addView(search, lp(-1, 52));
        addGap(page, 15);
        recordingsList = vertical();
        page.addView(recordingsList);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter = s.toString().trim().toLowerCase(Locale.ROOT);
                visibleLimit = 20;
                fillRecordings();
            }
            @Override public void afterTextChanged(Editable e) { }
        });
        fillRecordings();
    }
    private void fillRecordings() {
        if (recordingsList == null || totalLabel == null) return;
        recordingsList.removeAllViews();
        List<File> all;
        try { all = RecordingFiles.finished(this); }
        catch (RuntimeException e) {
            recordingsList.addView(label("Не удалось открыть папку: " + e.getMessage(), 14, DANGER, false));
            return;
        }
        long total = 0;
        for (File f : all) total += f.length();
        totalLabel.setText(all.size() + " файлов · " + RecordingFiles.prettySize(total));
        List<File> matching = new ArrayList<>();
        for (File f : all) if (f.getName().toLowerCase(Locale.ROOT).contains(filter)) matching.add(f);
        matching.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        if (matching.isEmpty()) {
            TextView empty = label("Записей пока нет. Начните запись на первой вкладке.", 15, MUTED, false);
            empty.setPadding(dp(12), dp(22), dp(12), dp(22));
            recordingsList.addView(empty);
            return;
        }
        for (int i = 0; i < Math.min(visibleLimit, matching.size()); i++) {
            File f = matching.get(i);
            addRecording(f, RetentionManager.isSaved(this, f));
        }
        if (matching.size() > visibleLimit) {
            addGap(recordingsList, 8);
            TextView more = action("Показать ещё 20", PANEL_LIGHT, TEXT, 12, () -> {
                visibleLimit += 20;
                fillRecordings();
            });
            recordingsList.addView(more, lp(-1, 49));
        }
    }
    private void addRecording(File f, boolean pinned) {
        LinearLayout block = vertical();
        block.setPadding(dp(14), dp(15), dp(14), dp(15));
        panelBackground(block, PANEL, 17);
        String date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
                .format(new Date(f.lastModified()));
        boolean incomplete = RecordingArchive.isUnfinished(f);
        block.addView(label((incomplete ? "⚠  " : pinned ? "◆  " : "◉  ") + date, 15, TEXT, true));
        addGap(block, 7);
        block.addView(label(f.getName() + "  ·  " + RecordingFiles.prettySize(f.length()), 11, MUTED, false));
        addGap(block, 13);
        LinearLayout buttons = horizontal();
        addSmallAction(buttons, "▶", ACCENT, BG, () -> playFile(f));
        addSmallAction(buttons, "⇩", PANEL_LIGHT, TEXT, () -> exportFile(f));
        if (RecordingFiles.isTemporary(f)) {
            addSmallAction(buttons, pinned ? "◆" : "◇", PANEL_LIGHT, pinned ? ACCENT : TEXT, () -> togglePin(f));
        } else {
            addSmallAction(buttons, "◆", PANEL_LIGHT, ACCENT, () -> toast("Автоудаление отключено для всех записей"));
        }
        addSmallAction(buttons, "✕", PANEL_LIGHT, DANGER, () -> confirmDelete(f));
        block.addView(buttons);
        addGap(block, 9);
        String protection = incomplete ? "⚠ НЕЗАВЕРШЁННЫЙ ФАЙЛ — сохранён после сбоя; воспроизведение не гарантировано, можно экспортировать" :
                "◆ ПОСТОЯННЫЙ АРХИВ — автоматическое удаление отключено";
        TextView subtitle = label(protection, 11, pinned ? ACCENT : MUTED, false);
        block.addView(subtitle);
        recordingsList.addView(block);
        addGap(recordingsList, 11);
    }
    private void addSmallAction(LinearLayout parent, String title, int bg, int fg, Runnable onClick) {
        TextView v = action(title, bg, fg, 12, onClick);
        v.setTextSize(19);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(43), 1);
        if (parent.getChildCount() > 0) params.leftMargin = dp(9);
        parent.addView(v, params);
    }
    private void togglePin(File f) {
        if (!RecordingFiles.isTemporary(f)) {
            toast("Эта запись хранится постоянно, до ручного удаления");
            return;
        }
        boolean target = !RetentionManager.isSaved(this, f);
        if (RetentionManager.setSaved(this, f, target)) {
            toast(target ? "Отмечено как избранное" : "Удалено из избранного — сам аудиофайл сохранён");
            fillRecordings();
        } else toast("Не удалось изменить защиту записи");
    }
    private void confirmDelete(File f) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить запись?")
                .setMessage(f.getName() + "\nДействие нельзя отменить.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить", (dialog, which) -> {
                    if (RetentionManager.isInUse(f) && !f.getAbsolutePath().equals(playingPath)) {
                        toast("Сначала завершите экспорт или другое использование файла");
                        return;
                    }
                    if (f.getAbsolutePath().equals(playingPath)) releasePlayer();
                    if (f.delete()) {
                        RetentionManager.forgetDeleted(this, f);
                        fillRecordings();
                    } else Toast.makeText(this, "Не удалось удалить файл", Toast.LENGTH_SHORT).show();
                }).show();
    }
    private void playFile(File f) {
        if (f.getAbsolutePath().equals(playingPath)) {
            if (player != null && player.isPlaying()) { player.pause(); toast("Пауза воспроизведения"); }
            else if (player != null) { player.start(); toast("Воспроизведение"); }
            return;
        }
        releasePlayer();
        if (!f.isFile()) { toast("Аудиофайл уже удалён"); fillRecordings(); return; }
        RetentionManager.reserve(f);
        try {
            playingPath = f.getAbsolutePath();
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setOnPreparedListener(mp -> { mp.start(); toast("Воспроизведение началось"); });
            player.setOnCompletionListener(mp -> { releasePlayer(); toast("Воспроизведение завершено"); });
            player.setOnErrorListener((mp, what, extra) -> {
                releasePlayer(); toast("Ошибка воспроизведения"); return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            releasePlayer();
            toast("Невозможно воспроизвести файл");
        }
    }
    private void releasePlayer() {
        if (playingPath != null) RetentionManager.release(new File(playingPath));
        if (player != null) {
            try { player.release(); } catch (RuntimeException ignored) { }
            player = null;
        }
        playingPath = null;
    }
    private void exportFile(File f) {
        if (!f.isFile()) { toast("Аудиофайл уже удалён"); fillRecordings(); return; }
        if (exportSource != null) RetentionManager.release(exportSource);
        RetentionManager.reserve(f);
        exportSource = f;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(RecordingArchive.isUnfinished(f) ? "application/octet-stream" : "audio/mp4");
        intent.putExtra(Intent.EXTRA_TITLE, f.getName());
        try { startActivityForResult(intent, SAVE_REQUEST); }
        catch (RuntimeException e) {
            RetentionManager.release(f);
            exportSource = null;
            toast("Не найдено приложение для сохранения файла");
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SAVE_REQUEST) return;
        File source = exportSource;
        exportSource = null;
        if (source == null) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            RetentionManager.release(source);
            return;
        }
        Uri destination = data.getData();
        new Thread(() -> {
            String message;
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
                if (out == null) throw new IllegalStateException("Не удалось открыть файл назначения");
                byte[] bytes = new byte[64 * 1024];
                int read;
                while ((read = in.read(bytes)) != -1) out.write(bytes, 0, read);
                out.flush();
                boolean protectedOriginal = RetentionManager.setSaved(this, source, true);
                message = protectedOriginal ? "Файл экспортирован, оригинал остался в архиве" :
                        "Файл экспортирован. Не удалось обновить отметку избранного";
            } catch (Exception e) {
                message = "Ошибка экспорта: " + e.getClass().getSimpleName();
            }
            RetentionManager.release(source);
            final String result = message;
            runOnUiThread(() -> {
                Toast.makeText(this, result, Toast.LENGTH_LONG).show();
                if (tab == 1 && !isFinishing() && !isDestroyed()) fillRecordings();
            });
        }, "EchoVault-export").start();
    }
    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    private void showSettings() {
        section("PREFERENCES / 03", "Настройте поток.", "Баланс чёткости, автономности и объёма файлов.");
        int quality = RecorderSettings.sanitizeQuality(settings().getInt(RecordingService.KEY_QUALITY, 1));
        int segment = settings().getInt(RecordingService.KEY_SEGMENT, 1);
        setting("КАЧЕСТВО АУДИО", RecorderSettings.QUALITY_LABELS[quality], "Изменить режим", () -> {
            new AlertDialog.Builder(this)
                    .setTitle("Качество записи")
                    .setSingleChoiceItems(RecorderSettings.QUALITY_LABELS, quality, (d, which) -> {
                        settings().edit().putInt(RecordingService.KEY_QUALITY, which).apply();
                        d.dismiss(); showTab(2);
                    }).setNegativeButton("Отмена", null).show();
        });
        addGap(page, 12);
        setting("ДЛИНА ОДНОГО ФАЙЛА", RecorderSettings.segmentMinutes(segment) + " минут",
                "Выбрать интервал", () -> {
                    String[] opts = {"15 минут", "30 минут", "60 минут"};
                    new AlertDialog.Builder(this).setTitle("Новый файл каждые…")
                            .setSingleChoiceItems(opts, Math.max(0, Math.min(2, segment)), (d, which) -> {
                                settings().edit().putInt(RecordingService.KEY_SEGMENT, which).apply();
                                d.dismiss(); showTab(2);
                            }).setNegativeButton("Отмена", null).show();
                });
        addGap(page, 12);
        setting("ЗАЩИТА ИСТОРИИ", "Автоудаление отключено",
                "Обновление сохраняет файлы предыдущих версий, включая Temporary и незавершённые .partial. " +
                "Файлы удаляются только по вашему подтверждению или при очистке данных/удалении приложения.", null);
        addGap(page, 23);
        page.addView(label("РАСХОД ПАМЯТИ ЗА 24 ЧАСА", 11, ACCENT, true));
        addGap(page, 9);
        page.addView(label("≈ " + RecordingFiles.prettySize(RecorderSettings.estimatedBytesPerDay(quality)), 31, TEXT, true));
        addGap(page, 5);
        page.addView(label("Примерная оценка при непрерывной записи в выбранном качестве", 12, MUTED, false));
        addGap(page, 20);
        long free = RecordingFiles.directory(this).getUsableSpace();
        setting("СВОБОДНОЕ МЕСТО", RecordingFiles.prettySize(free), "Запись автоматически остановится при остатке менее 200 МБ", null);
        addGap(page, 12);
        setting("КОНФИДЕНЦИАЛЬНОСТЬ", "100% локально", "Нет интернета, аналитики или доступа к файлам других приложений", null);
        addGap(page, 24);
        TextView caution = label("Служба записывает после запуска до остановки или ограничения системой. После перезагрузки запись нужно запустить вновь. Все завершённые фрагменты теперь остаются в архиве без срока удаления. Если Android прервёт запись, необработанный .partial сохраняется и виден в истории, но может оказаться непригоден для воспроизведения. При удалении приложения или очистке данных локальные аудиофайлы могут исчезнуть: экспортируйте важные записи в другую папку.", 13, MUTED, false);
        caution.setLineSpacing(dp(5), 1.0f);
        page.addView(caution);
    }
    private void setting(String key, String value, String description, Runnable callback) {
        LinearLayout box = vertical();
        box.setPadding(dp(17), dp(18), dp(17), dp(19));
        panelBackground(box, PANEL, 17);
        box.addView(label(key, 11, ACCENT, true));
        addGap(box, 8);
        box.addView(label(value, 18, TEXT, true));
        addGap(box, 7);
        TextView detail = label(description, 12, MUTED, false);
        detail.setLineSpacing(dp(3), 1f);
        box.addView(detail);
        if (callback != null) {
            box.setOnClickListener(v -> callback.run());
            box.setFocusable(true);
            box.setClickable(true);
        }
        page.addView(box);
    }

    private static final class WaveformView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        WaveformView(Context c) { super(c); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth(), height = getHeight();
            float base = height / 2f;
            int count = 35;
            float gap = width / (count + 1);
            boolean moving = RecordingService.isActive() && !RecordingService.isPaused();
            float phase = moving ? SystemClock.uptimeMillis() * .0024f : 0f;
            for (int i = 0; i < count; i++) {
                float envelope = .35f + .65f * (float)Math.pow(Math.sin(Math.PI * (i + 1) / (count + 1)), 1.8);
                float fluctuation = moving
                        ? (.31f + .69f * Math.abs((float)Math.sin(i * .67f + phase) * (float)Math.cos(i * .22f - phase * .67f)))
                        : (.20f + .17f * (float)Math.abs(Math.sin(i * .8f)));
                float barHeight = Math.max(4f, height * envelope * fluctuation);
                float x = gap * (i + 1);
                paint.setColor(i % 5 == 0 ? Color.rgb(188, 255, 224) : ACCENT);
                paint.setAlpha(moving ? 235 : 125);
                canvas.drawRoundRect(x - gap * .23f, base - barHeight / 2,
                        x + gap * .23f, base + barHeight / 2, gap * .25f, gap * .25f, paint);
            }
            if (moving && isShown()) postInvalidateDelayed(90L);
        }
    }
}
