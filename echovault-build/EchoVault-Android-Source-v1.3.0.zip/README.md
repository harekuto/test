# EchoVault · Android 24/7 Voice Recorder

**Current source release: v1.3.0 (permanent local archive).** Earlier v1.1/v1.2 sections below are release history, not current retention behavior. For existing v1.2 installations, disable automatic deletion immediately until a same-signature update is available.

Native Android voice recorder (Java) built around the platform `MediaRecorder` microphone foreground service. UI language: Russian. Package: `com.harekuto.echovault`. No third-party runtime libraries, no Internet permission, no accounts, no cloud transmission, no advertisement or analytics.

## What is implemented

- User-initiated recording that continues in a **microphone foreground service** when the app is backgrounded or the screen is off.
- Permanent visible service notification and **Pause / Resume / Stop** actions.
- Energy-conscious AAC-LC/MPEG-4 mono recording with three presets: 16 kHz/32 kbit/s, 24 kHz/48 kbit/s (default), 44.1 kHz/96 kbit/s. Settings apply at next recording start.
- Segmented `.m4a` recordings every 15/30/60 minutes (default: 30). MediaRecorder rotation can create brief gaps at segment boundaries; it is **not gapless**.
- Files saved locally to app-specific external files (`Android/data/com.harekuto.echovault/files/Music/EchoVault` or internal fallback), finalized at stop/segment rotation. All completed recordings are retained: there is no time-based automatic deletion in v1.3.0.
- Local archive with search, newest-first listing, legacy favorites (the old pinned records), pagination, playback, export and explicit deletion confirmation. Old v1.2 Temporary files and unfinished .partial files remain visible.
- Export of individual recordings using Android Storage Access Framework to Downloads or other user-chosen location. Export does not delete the original.
- Low-storage safety stop if free storage is under 200 MiB before recording the next segment.
- Legacy scheduled cleanup is canceled; the cleanup service cannot delete audio. No wake lock, no CPU-intensive noise removal, no PCM polling while the app is in the background.

## Platform and limits

- Minimum Android 8.0 (API 26), compile/target SDK 35. Requires a working microphone.
- Android 14+ requires `FOREGROUND_SERVICE_MICROPHONE` and runtime `RECORD_AUDIO`; start recording from the visible app. Background re-start (e.g. after a phone reboot) is **not supported**. Automatic boot-time microphone recording is restricted by Android.
- An ongoing foreground service **improves continuity**, but does not guarantee literal uninterrupted 24/7 recording: OEM battery management, permission revocations, audio-source contention, system termination, device shutdown, file-system failures and storage exhaustion can stop it.
- Android can display a microphone privacy indicator; recording is not hidden or covert.
- No universal guarantee of intelligible speech: microphone hardware, proximity, ambient noise and speaker position matter. Choose Hi-Fi mode for improved fidelity, with higher file sizes.
- Foreground notification visibility depends on Android 13+ notification permission; Android still exposes running foreground service and microphone access to the user.
- App-local recordings may be removed when uninstalling or clearing app data. **Export important recordings first.** There is no cloud backup.
- Ensure compliance with consent and recording laws applicable to the location and participants.

## Build on Windows (Android Studio)

1. Install Android Studio (with Android SDK Platform 35, SDK Build Tools and JDK 17) and **Gradle 8.9**. Internet access is required for the Android Gradle Plugin and JUnit dependency on the first build.
2. Open this `EchoVault` project (the folder containing `settings.gradle`) in Android Studio.
3. Configure Gradle 8.9 under **Settings → Build, Execution, Deployment → Build Tools → Gradle**, or run `gradle wrapper --gradle-version 8.9` once in an environment that has Gradle installed (this creates the standard Gradle wrapper scripts and JAR).
4. Sync project, run `:app:testDebugUnitTest` and `:app:assembleDebug`.
5. The built debug APK is at `app/build/outputs/apk/debug/app-debug.apk`. This path describes the expected output; it does not mean an APK is included in this source archive.
6. Install the actual APK on your Android device; grant Microphone access, and optionally Notifications. Start recording from the visible app. Test a 30+ minute session with screen off on the actual device.

## Build environment status for this archive

- Source project authored and inspected.
- Android SDK, Gradle and Android platform tools were **not available** in the authoring environment; `assembleDebug`/APK, instrumented device testing and long-running background tests could not be run here.
- This archive contains **source code**, not a compiled APK. Do not distribute as a tested release before running Android build and device QA.

## Battery/storage estimates

- AAC payload at 32 kbit/s: ~346 MB/day; 48 kbit/s: ~518 MB/day; 96 kbit/s: ~1.04 GB/day (decimal MB, plus container overhead).
- This project uses no continuous CPU wake lock. Microphone use and audio capture still require power, and exact battery drain must be measured on a real device.
- Recommended QA: locked-screen recording for 8–24h, Android 14/15/16, incoming calls, Bluetooth disconnect, low storage, permission revocation, process/system kill, rotation boundaries, playback, export and exact battery drain.

## Architecture

- `MainActivity.java`: privacy-visible UI, permissions, archive, export, player, options.
- `RecordingService.java`: foreground microphone recorder and segment lifecycle.
- `RecordingFiles.java`: app-specific file management.
- `RecorderSettings.java`: pure-Java recording and storage configuration.
- `RecorderSettingsTest.java`: pure-Java config and storage estimator regression tests.

## Notes

No Gradle wrapper binary is embedded because an authentic Gradle wrapper JAR was not available offline. Generate it using standard `gradle wrapper --gradle-version 8.9` or use an IDE-managed Gradle installation. Avoid downloading wrapper binaries from untrusted third-party sources.

## v1.1.0 · Auto-cleanup

Open Settings > Automatic deletion to choose Never / 12 / 24 / 48 / 72 hours / 7 / 30 days. Default is Never, to avoid surprise deletion of files created with older versions. Switching on cleanup requires confirmation and may immediately remove older unprotected files.

Recordings are segmented as before, and a segment expires based on its finalization time (`lastModified`). In Archive, the diamond (◇) toggles durable protection (◆). Existing pinned files carry over and remain protected. A successful export also protects the local original; exported copies outside the application are never touched. Active playback or in-progress export is reserved against expiry. Android JobScheduler runs periodic low-power maintenance and files are also checked on app open and segment rotation, so expiry is approximate rather than minute-exact (especially under Doze).

**Upgrade caveat:** v1.0.0 was a test-debug APK with an ephemeral CI signing key. A separately built debug APK may not upgrade over it. Export all important audio *before* uninstalling v1.0.0, or data may be lost.

## v1.2.0 · rolling daily archive
- After user-initiated start, the Android microphone foreground service continues recording across midnight until stopped, OS-terminated, microphone unavailable or low disk. Android prohibits reliable boot auto-restart of microphone foreground services.
- Newly recorded M4A segments live in EchoVault/Temporary, completely isolated from existing root-level legacy recordings. Only temporary unprotected segments may be deleted by periodic retention (default: 48h, adjustable 12h/24h/48h/72h/7d/30d/off). The time limit starts when each segment is finalized; Android scheduler may run late.
- Archive ◆ protects a segment, .m4a.keep alongside protected temporary segments survives loss of the preference flag; export also protects the original. Legacy root recordings are never pruned by the rolling retention policy, and may be deleted manually.
- During ongoing recording the Save current fragment button and notification action finalize and protect the ongoing chunk, then begin a new temporary chunk. The recorder must be running and not paused. This does not retroactively merge multiple older segments.
- IMPORTANT: the GitHub Actions debug signing key is regenerated on hosted runners. Android may reject direct upgrades from earlier APKs; export important old audio before uninstalling an old app. Do not wipe app data before export.

## v1.3.0 · Permanent history and safe audio finalization (2026-10-20)

This release supersedes the v1.2.0 rolling-delete behavior described above. **No automatic recording deletion occurs in v1.3.0, even when `retention_hours` was 48 or another nonzero value in v1.2.0.** Previously scheduled JobScheduler deletion jobs are canceled, and legacy cleanup entrypoints never remove files. Manual deletion is still available behind an explicit confirmation; uninstall / Clear storage can still remove app-private audio.

- New captured segments are saved in the main EchoVault directory, not the legacy `Temporary` subdirectory. They start under a unique `.m4a.partial` name; after `MediaRecorder.stop()` the file must provide readable Android media duration metadata before it is renamed to `.m4a` without overwriting existing files.
- Failed stops, media validation failures, and failed renames **retain the `.partial` bytes** instead of deleting them. The archive displays orphaned partials (except the currently recording partial) and allows export. MP4 containers interrupted before their `moov` metadata was written may remain unplayable; visibility is not audio restoration.
- The archive indexes recordings under both app-specific external Music/EchoVault and internal files/EchoVault roots, and under each root's legacy `Temporary` folder. No automatic moving or rewriting of older recordings.
- Archive entries are newest-first, regardless of whether a legacy file is marked protected. v1.2 favorite `.keep` markers and settings remain compatible. Files currently reserved by a running export are protected against manual deletion until release.
- Application id `com.harekuto.echovault`, SDK levels, resource IDs, exported components, and permission behavior remain unchanged. Version code 4 / version name 1.3.0.
- **Compatibility warning:** In-place upgrades preserve existing app data only when the new APK is signed with the *same signing certificate* as the installed v1.2.0 APK. This source ZIP contains no signing key, Android SDK, Gradle binary, or compiled v1.3.0 APK. Do NOT uninstall v1.2.0 to force installation; export important recordings first to a location outside Android/data. If external storage is unmounted, it must become available before files stored there can appear in history.

### v1.3.0 validation status

14 pure-Java tests passed with a minimal local JUnit-compatible assertion/annotation harness; Java syntax parsing passed for 11 source/test files; Android manifest/resource XML parsing passed for 6 files. **No real Android SDK compile, Android Gradle build, APK installation, emulator, device microphone recording, or playback test was possible in this environment.** See `QA_REPORT.md`. The supplied v1.2.0 APK has not been replaced or renamed.
