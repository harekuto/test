package com.harekuto.echovault;

import org.junit.Test;
import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.*;

public final class RecordingArchiveTest {
    @Test public void scansBothLegacyAndRollingAndCrashFilesWithoutModifyingThem() throws Exception {
        File root = Files.createTempDirectory("ev-history").toFile();
        try {
            File temp = new File(root, "Temporary");
            assertTrue(temp.mkdir());
            File original = new File(root, "EV_old.m4a");
            File rolling = new File(temp, "EV_old_rolling.m4a");
            File interrupted = new File(temp, "EV_interrupted.m4a.partial");
            File active = new File(root, "EV_active.m4a.partial");
            for (File f : Arrays.asList(original, rolling, interrupted, active)) {
                assertTrue(f.createNewFile());
            }
            List<File> found = RecordingArchive.scan(Arrays.asList(root, root), active.getAbsolutePath());
            assertEquals(3, found.size());
            assertTrue(found.contains(original));
            assertTrue(found.contains(rolling));
            assertTrue(found.contains(interrupted));
            assertFalse(found.contains(active));
            assertTrue(original.isFile());
            assertTrue(rolling.isFile());
            assertTrue(interrupted.isFile());
        } finally {
            File[] contents = new File(root, "Temporary").listFiles();
            if (contents != null) for (File f : contents) assertTrue(f.delete());
            assertTrue(new File(root, "Temporary").delete());
            contents = root.listFiles();
            if (contents != null) for (File f : contents) assertTrue(f.delete());
            assertTrue(root.delete());
        }
    }

    @Test public void uniquePartialFilesNeverOverwriteOneAnother() throws Exception {
        File root = Files.createTempDirectory("ev-name").toFile();
        try {
            File first = RecordingArchive.reserveNewPartial(root, "same-timestamp");
            File second = RecordingArchive.reserveNewPartial(root, "same-timestamp");
            assertNotEquals(first.getName(), second.getName());
            Files.write(first.toPath(), new byte[] {1, 2, 3});
            Files.write(second.toPath(), new byte[] {4, 5});
            File target = RecordingArchive.finishedName(first);
            assertTrue(RecordingArchive.finalizeWithoutOverwrite(first, target));
            assertFalse(first.exists());
            assertEquals(3L, target.length());
            assertTrue(second.exists());
            assertEquals(2L, second.length());
            // A second move must refuse to overwrite an existing archive file.
            File collision = new File(root, target.getName() + ".partial");
            Files.write(collision.toPath(), new byte[] {9});
            assertFalse(RecordingArchive.finalizeWithoutOverwrite(collision, target));
            assertTrue(collision.exists());
            assertEquals(3L, target.length());
        } finally {
            File[] contents = root.listFiles();
            if (contents != null) for (File f : contents) assertTrue(f.delete());
            assertTrue(root.delete());
        }
    }
    @Test public void discoversInternalAndExternalArchivesTogether() throws Exception {
        File parent = Files.createTempDirectory("ev-storage-switch").toFile();
        try {
            File internal = new File(parent, "internal");
            File external = new File(parent, "external");
            assertTrue(internal.mkdir());
            assertTrue(external.mkdir());
            File inside = new File(internal, "EV_internal.m4a");
            File outside = new File(external, "EV_external.m4a");
            assertTrue(inside.createNewFile());
            assertTrue(outside.createNewFile());
            List<File> files = RecordingArchive.scan(Arrays.asList(external, internal), "");
            assertEquals(2, files.size());
            assertTrue(files.contains(inside));
            assertTrue(files.contains(outside));
        } finally {
            for (String name : Arrays.asList("internal", "external")) {
                File dir = new File(parent, name);
                File[] items = dir.listFiles();
                if (items != null) for (File f : items) assertTrue(f.delete());
                assertTrue(dir.delete());
            }
            assertTrue(parent.delete());
        }
    }

}
