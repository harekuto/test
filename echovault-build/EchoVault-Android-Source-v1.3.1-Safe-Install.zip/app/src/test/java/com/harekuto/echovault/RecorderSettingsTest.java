package com.harekuto.echovault;

import org.junit.Test;
import static org.junit.Assert.*;

public final class RecorderSettingsTest {
    @Test public void clampsQuality() {
        assertEquals(0, RecorderSettings.sanitizeQuality(-50));
        assertEquals(1, RecorderSettings.sanitizeQuality(1));
        assertEquals(2, RecorderSettings.sanitizeQuality(50));
    }
    @Test public void expectedEncoderSettings() {
        assertEquals(16000, RecorderSettings.sampleRate(0));
        assertEquals(48000, RecorderSettings.bitRate(1));
        assertEquals(44100, RecorderSettings.sampleRate(2));
        assertEquals(96000, RecorderSettings.bitRate(2));
    }
    @Test public void storageEstimates() {
        assertEquals(345600000L, RecorderSettings.estimatedBytesPerDay(0));
        assertEquals(518400000L, RecorderSettings.estimatedBytesPerDay(1));
        assertEquals(1036800000L, RecorderSettings.estimatedBytesPerDay(2));
    }
    @Test public void safeSegmentDuration() {
        assertEquals(15, RecorderSettings.segmentMinutes(-10));
        assertEquals(30, RecorderSettings.segmentMinutes(1));
        assertEquals(60, RecorderSettings.segmentMinutes(200));
    }
}
