package com.harekuto.echovault;

import org.junit.Test;
import static org.junit.Assert.*;

public final class RetentionPolicyTest {
    private static final long HOUR = 60L * 60L * 1000L;
    @Test public void freshInstallDefaultsToPermanentStorage() {
        assertEquals(0, RetentionPolicy.DEFAULT_HOURS);
        assertEquals(0, RetentionPolicy.indexOf(RetentionPolicy.DEFAULT_HOURS));
    }
    @Test public void legacyAndSavedAlwaysSurvive() {
        long then = 1000L * HOUR, after = then + 100L * HOUR;
        assertFalse(RetentionPolicy.mayDelete(false, false, then, after, 48));
        assertFalse(RetentionPolicy.mayDelete(true, true, then, after, 48));
        assertFalse(RetentionPolicy.mayDelete(true, false, then, after, 48));
        assertFalse(RetentionPolicy.mayDelete(true, false, then, after, 0));
    }
    @Test public void disabledNeverDeletes() {
        assertFalse(RetentionPolicy.expired(1L, 10000L * HOUR, 0));
    }
    @Test public void exact48HourBoundary() {
        long then = 1000L * HOUR;
        assertFalse(RetentionPolicy.expired(then, then + 48 * HOUR - 1, 48));
        assertTrue(RetentionPolicy.expired(then, then + 48 * HOUR, 48));
    }
    @Test public void invalidSettingFailsClosed() {
        assertEquals(0, RetentionPolicy.sanitize(-48));
        assertEquals(0, RetentionPolicy.sanitize(1));
        assertEquals(0, RetentionPolicy.sanitize(999));
        assertFalse(RetentionPolicy.expired(1L, 99999L * HOUR, 1));
    }
    @Test public void futureOrUnknownTimestampNotDeleted() {
        assertFalse(RetentionPolicy.expired(0, 500L * HOUR, 48));
        assertFalse(RetentionPolicy.expired(600L * HOUR, 500L * HOUR, 48));
    }
    @Test public void eachDurationSelectable() {
        assertEquals(0, RetentionPolicy.indexOf(0));
        assertEquals(3, RetentionPolicy.indexOf(48));
        assertEquals(6, RetentionPolicy.indexOf(720));
        assertEquals(0, RetentionPolicy.indexOf(900));
        assertEquals(RetentionPolicy.HOURS.length, RetentionPolicy.LABELS.length);
    }
}
