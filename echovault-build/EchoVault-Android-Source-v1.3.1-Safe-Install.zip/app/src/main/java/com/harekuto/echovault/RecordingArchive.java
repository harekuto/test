package com.harekuto.echovault;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Pure-Java archive index. Read-only discovery: never migrates, truncates or deletes existing audio. */
public final class RecordingArchive {
    private RecordingArchive() { }

    public static boolean isRecordingName(String name) {
        return name.startsWith("EV_") && (name.endsWith(".m4a") || name.endsWith(".m4a.partial"));
    }

    public static boolean isUnfinished(File file) {
        return file.getName().endsWith(".m4a.partial");
    }

    /** Include legacy root recordings, v1.2 Temporary recordings and interrupted partials. */
    public static List<File> scan(List<File> roots, String activePartialPath) {
        List<File> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (File root : roots) {
            collect(root, activePartialPath, seen, result);
            collect(new File(root, "Temporary"), activePartialPath, seen, result);
        }
        result.sort((a, b) -> {
            int byTime = Long.compare(b.lastModified(), a.lastModified());
            return byTime != 0 ? byTime : a.getAbsolutePath().compareTo(b.getAbsolutePath());
        });
        return result;
    }

    private static void collect(File directory, String activePartialPath,
                                Set<String> seen, List<File> result) {
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isFile() && isRecordingName(file.getName()) &&
                    !file.getAbsolutePath().equals(activePartialPath) &&
                    seen.add(file.getAbsolutePath())) {
                result.add(file);
            }
        }
    }

    /** File.createTempFile reserves a unique name instead of ever truncating an older recording. */
    public static File reserveNewPartial(File directory, String timestamp) throws IOException {
        return File.createTempFile("EV_" + timestamp + "_", ".m4a.partial", directory);
    }

    public static File finishedName(File partial) {
        String name = partial.getName();
        if (!isUnfinished(partial)) throw new IllegalArgumentException("Not an audio partial");
        return new File(partial.getParentFile(), name.substring(0, name.length() - ".partial".length()));
    }

    /** Rename only after media validation by the caller; never replace an existing target. */
    public static boolean finalizeWithoutOverwrite(File partial, File finished) {
        if (!partial.isFile() || partial.length() == 0 || finished.exists()) return false;
        try {
            // Same-directory move, without REPLACE_EXISTING; fail closed on collisions.
            Files.move(partial.toPath(), finished.toPath());
            return true;
        } catch (IOException | SecurityException ignored) {
            // Preserve the original .partial for recovery/export if moving fails.
            return false;
        }
    }
}
