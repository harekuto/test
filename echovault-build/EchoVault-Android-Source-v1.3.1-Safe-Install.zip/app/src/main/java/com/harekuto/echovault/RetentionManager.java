package com.harekuto.echovault;

import android.app.job.JobScheduler;
import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** Maintains legacy favorites and file-use reservations; automatic deletion is permanently disabled. */
public final class RetentionManager {
    public static final String KEY_HOURS = "retention_hours";
    private static final String KEY_SAVED = "pinned"; // v1 archive pins are preserved as saved recordings.
    private static final int JOB_ID = 936042;
    private static final Object LOCK = new Object();
    private static final Map<String, Integer> IN_USE = new HashMap<>();

    private RetentionManager() { }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(RecordingService.PREFS, Context.MODE_PRIVATE);
    }

    /** v1.3 disables background deletion even for users who enabled it in v1.2. */
    public static int getHours(Context context) {
        return 0;
    }

    public static void setHours(Context context, int hours) {
        if (hours != 0) throw new IllegalArgumentException("Automatic deletion is disabled in v1.3");
        if (!preferences(context).edit().putInt(KEY_HOURS, 0).commit()) {
            throw new IllegalStateException("Не удалось сохранить отключение автоудаления");
        }
        configureJob(context);
    }

    /** Remove a persisted v1.2 periodic delete job on every normal app/service launch. */
    public static void configureJob(Context context) {
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        if (scheduler != null) scheduler.cancel(JOB_ID);
        // Old retention_hours may still read 48. Ignore it: prune() cannot delete.
    }

    /** Shared lock ensures the cleanup cannot race with Save/Unsave. */
    public static boolean setSaved(Context context, File file, boolean saved) {
        synchronized (LOCK) {
            if (!file.isFile()) return false;
            SharedPreferences prefs = preferences(context);
            Set<String> names = new HashSet<>(prefs.getStringSet(KEY_SAVED, new HashSet<>()));
            if (!RecordingFiles.isTemporary(file)) return true; // Root recordings are permanent and require no marker.
            // A .keep marker makes deliberate saves survive preference loss and upgrades.
            File marker = new File(file.getAbsolutePath() + ".keep");
            try {
                if (saved) {
                    if (!marker.isFile() && !marker.createNewFile()) return false;
                    names.add(file.getName());
                } else {
                    if (marker.exists() && !marker.delete()) return false;
                    names.remove(file.getName());
                }
            } catch (java.io.IOException e) { return false; }
            return prefs.edit().putStringSet(KEY_SAVED, names).commit();
        }
    }

    public static void forgetDeleted(Context context, File file) {
        synchronized (LOCK) {
            SharedPreferences prefs = preferences(context);
            Set<String> names = new HashSet<>(prefs.getStringSet(KEY_SAVED, new HashSet<>()));
            if (names.remove(file.getName())) prefs.edit().putStringSet(KEY_SAVED, names).commit();
            // If the recording is deleted manually, also remove its keep marker.
            File marker = new File(file.getAbsolutePath() + ".keep");
            if (marker.exists()) marker.delete();
        }
    }

    public static boolean isSaved(Context context, File file) {
        synchronized (LOCK) {
            return !RecordingFiles.isTemporary(file) ||
                    preferences(context).getStringSet(KEY_SAVED, new HashSet<>()).contains(file.getName()) ||
                    new File(file.getAbsolutePath() + ".keep").isFile();
        }
    }

    public static void reserve(File file) {
        synchronized (LOCK) {
            String path = file.getAbsolutePath();
            IN_USE.put(path, IN_USE.getOrDefault(path, 0) + 1);
        }
    }
    public static void release(File file) {
        synchronized (LOCK) {
            String path = file.getAbsolutePath();
            int count = IN_USE.getOrDefault(path, 0);
            if (count <= 1) IN_USE.remove(path);
            else IN_USE.put(path, count - 1);
        }
    }

    public static boolean isInUse(File file) {
        synchronized (LOCK) {
            return IN_USE.containsKey(file.getAbsolutePath());
        }
    }

    /** No background retention deletions are permitted, including pre-upgrade temporary files. */
    public static int prune(Context context) {
        return 0;
    }

    public static void pruneAsync(Context context, Runnable after) {
        if (after != null) after.run();
    }
}
