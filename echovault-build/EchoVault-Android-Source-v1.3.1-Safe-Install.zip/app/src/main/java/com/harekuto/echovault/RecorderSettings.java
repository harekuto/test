package com.harekuto.echovault;

/** Pure-Java codec/storage configuration; no allocations on the recording path. */
public final class RecorderSettings {
    public static final String[] QUALITY_LABELS = {
            "Экономный · 16 кГц / 32 Кбит/с",
            "Баланс · 24 кГц / 48 Кбит/с",
            "Чёткий · 44,1 кГц / 96 Кбит/с"
    };
    public static final int[] SEGMENT_MINUTES = {15, 30, 60};
    private static final int[] SAMPLE_RATES = {16000, 24000, 44100};
    private static final int[] BIT_RATES = {32000, 48000, 96000};
    private RecorderSettings() { }

    public static int sanitizeQuality(int value) { return Math.max(0, Math.min(2, value)); }
    public static int sampleRate(int value) { return SAMPLE_RATES[sanitizeQuality(value)]; }
    public static int bitRate(int value) { return BIT_RATES[sanitizeQuality(value)]; }
    public static int segmentMinutes(int index) {
        return SEGMENT_MINUTES[Math.max(0, Math.min(2, index))];
    }
    public static long estimatedBytesPerDay(int quality) {
        // Approximate encoded payload; MP4 framing adds a small overhead.
        return (long) bitRate(quality) * 86400L / 8L;
    }
}
