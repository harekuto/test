package com.harekuto.echovault;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class RecordingFiles {
    private RecordingFiles() { }

    public static File directory(Context context) {
        File root = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (root == null) root = context.getFilesDir();
        File folder = new File(root, "EchoVault");
        if (!folder.exists() && !folder.mkdirs() && !folder.isDirectory()) {
            throw new IllegalStateException("Не удалось создать папку записей");
        }
        return folder;
    }
    /** Older v1.2.0 files are read from Temporary, but new files are permanently archived in root. */
    public static File temporaryDirectory(Context context) {
        File folder = new File(directory(context), "Temporary");
        if (!folder.exists() && !folder.mkdirs() && !folder.isDirectory()) {
            throw new IllegalStateException("Не удалось создать папку старого архива");
        }
        return folder;
    }
    public static boolean isTemporary(File file) {
        return file.getParentFile() != null && "Temporary".equals(file.getParentFile().getName());
    }
    public static String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS", Locale.ROOT).format(new Date());
    }
    /** Never hide older internal recordings when external storage becomes available (or vice versa). */
    public static List<File> finished(Context context) {
        List<File> roots = new ArrayList<>();
        File external = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (external != null) roots.add(new File(external, "EchoVault"));
        roots.add(new File(context.getFilesDir(), "EchoVault"));
        return RecordingArchive.scan(roots, RecordingService.currentPartialPath());
    }
    public static String prettySize(long bytes) {
        if (bytes >= 1073741824L) return String.format(Locale.getDefault(), "%.2f ГБ", bytes / 1073741824.0);
        if (bytes >= 1048576L) return String.format(Locale.getDefault(), "%.1f МБ", bytes / 1048576.0);
        return String.format(Locale.getDefault(), "%.0f КБ", bytes / 1024.0);
    }
}
