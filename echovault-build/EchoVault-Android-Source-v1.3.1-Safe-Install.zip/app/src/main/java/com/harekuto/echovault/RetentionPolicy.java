package com.harekuto.echovault;

/** Legacy expiry durations retained for settings compatibility; v1.3 never deletes audio. */
public final class RetentionPolicy {
    public static final int DEFAULT_HOURS = 0;
    public static final int[] HOURS = {0, 12, 24, 48, 72, 168, 720};
    public static final String[] LABELS = {
            "Не удалять автоматически", "12 часов", "24 часа", "48 часов", "72 часа", "7 дней", "30 дней"
    };
    private RetentionPolicy() { }

    public static int sanitize(int hours) {
        for (int allowed : HOURS) if (allowed == hours) return hours;
        return 0; // Fail safe: never delete with an invalid setting.
    }

    public static int indexOf(int hours) {
        int allowed = sanitize(hours);
        for (int i = 0; i < HOURS.length; i++) if (HOURS[i] == allowed) return i;
        return 0;
    }

    /** Never delete a legacy recording or a user-protected segment. */
    public static boolean mayDelete(boolean isTemporary, boolean saved,
                                    long finalizedAtMillis, long nowMillis, int hours) {
        return false; // v1.3: archival recordings are never eligible for automatic deletion.
    }

    public static boolean expired(long finalizedAtMillis, long nowMillis, int hours) {
        int allowed = sanitize(hours);
        if (allowed == 0 || finalizedAtMillis <= 0 || nowMillis < finalizedAtMillis) return false;
        return nowMillis - finalizedAtMillis >= allowed * 60L * 60L * 1000L;
    }
}
