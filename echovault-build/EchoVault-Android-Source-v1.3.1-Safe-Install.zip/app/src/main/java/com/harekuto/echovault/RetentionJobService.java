package com.harekuto.echovault;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Compatibility target for pre-upgrade scheduled jobs. Never deletes recordings. */
public final class RetentionJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        return false; // Completed synchronously without touching any file.
    }
    @Override public boolean onStopJob(JobParameters params) { return false; }
}
