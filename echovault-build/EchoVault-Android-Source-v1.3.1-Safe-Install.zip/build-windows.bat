@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Gradle 8.9 is not on PATH. See README.md for Android Studio setup.
  exit /b 1
)
echo [1/2] Running unit tests...
call gradle :app:testDebugUnitTest --no-daemon
if errorlevel 1 exit /b 1
echo [2/2] Building Android APK...
call gradle :app:assembleDebug --no-daemon
if errorlevel 1 exit /b 1
if not exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo [ERROR] Gradle completed but expected APK was not found.
  exit /b 1
)
echo [SUCCESS] app\build\outputs\apk\debug\app-debug.apk
exit /b 0
